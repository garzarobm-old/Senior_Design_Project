
#include <stdint.h>



/* if you want to insert class definitions */
#ifdef __cplusplus

#endif

/* END OF CLASS DEFINITIONS */




/*C++ declaration in a header file for C files*/

#ifdef __cplusplus

extern "C" int h(int i);

#endif




