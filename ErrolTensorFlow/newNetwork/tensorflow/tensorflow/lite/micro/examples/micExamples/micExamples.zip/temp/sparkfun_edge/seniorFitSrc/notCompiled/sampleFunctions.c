
/* to implement practice calls C++ */


#include <stdint.h>

 /* C code: */
int h(int i)	{
	
	return i + 2;
}
