/* Copyright 2019 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

// See the header for documentation on the meaning of this data.

#include "tensorflow/lite/micro/examples/micro_speech/micro_features/no_feature_data_slice.h"

const uint8_t g_no_feature_data_slice[g_no_feature_data_slice_size] = {
    216, 195, 223, 211, 238, 223, 243, 215, 226, 204, 232, 211, 232, 213,
    240, 218, 235, 214, 238, 205, 207, 173, 149, 201, 215, 200, 230, 213,
    208, 195, 175, 151, 195, 175, 182, 163, 235, 217, 218, 190,
};
