
#include "tensorflow/lite/micro/examples/micro_speech/miguelimport.h"
#include "tensorflow/lite/micro/examples/micro_speech/micro_features/micro_model_settings.h"



void Call(int a){


/*start of miguel implement */
    
/*miguel implement */

}
